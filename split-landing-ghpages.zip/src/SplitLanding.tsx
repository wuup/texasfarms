import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, ShoppingCart, Info, ArrowRight } from "lucide-react";

function cn(...c){return c.filter(Boolean).join(" ");}
function Button({asChild, className="", variant="default", size="md", ...props}: any){
  const base="inline-flex items-center justify-center font-medium transition-colors focus:outline-none focus:ring-4";
  const sizes={sm:"h-9 px-3 rounded-xl text-sm", md:"h-10 px-4 rounded-2xl", lg:"h-12 px-6 rounded-2xl text-lg"} as const;
  const variants={default:"bg-primary text-white hover:opacity-90 focus:ring-primary/30", outline:"border border-white/30 text-foreground hover:bg-white/5 focus:ring-white/20"} as const;
  const cls=cn(base, sizes[size], variants[variant], className);
  return asChild ? <span className={cls} {...props}/> : <button className={cls} {...props}/>;
}
function Card(p:any){return <div {...p} className={cn("rounded-2xl border bg-white/5", p.className)} />}
function CardHeader(p:any){return <div {...p} className={cn("p-4", p.className)} />}
function CardTitle(p:any){return <h3 {...p} className={cn("font-semibold", p.className)} />}
function CardContent(p:any){return <div {...p} className={cn("p-4", p.className)} />}

const DELIVERY_ZIPS = ["05819", "05843", "05855", "05824", "03584", "05873"];

const SECTIONS = [
  { id:"left", title:"Learn About the Farm", subtitle:"Our practices, animals & story",
    bgImage:"https://images.unsplash.com/photo-1500530855697-b586d89ba3ee?q=80&w=1600&auto=format&fit=crop",
    items:[
      { title:"Our Story", description:"How we raise Gloucestershire Old Spot pigs, soil-first, no‑till ethos.", icon:<Info className="w-4 h-4"/>, href:"#our-story" },
      { title:"Animal Welfare & Practices", description:"Pasture rotation, feed, and stewardship standards you can trust.", icon:<ArrowRight className="w-4 h-4"/>, href:"#practices" },
    ]},
  { id:"right", title:"Place an Order", subtitle:"Pick up or local delivery",
    bgImage:"https://images.unsplash.com/photo-1511690656952-34342bb7c2f2?q=80&w=1600&auto=format&fit=crop",
    items:[
      { title:"Order for Pickup", description:"Reserve cuts and boxes online; pick up at farm or market.", icon:<ShoppingCart className="w-4 h-4"/>, href:"/order?method=pickup" },
      { title:"Local Delivery", description:"We deliver nearby—enter your ZIP to see options and schedule.", icon:<ArrowRight className="w-4 h-4"/>, href:"#local-delivery" },
    ]},
];

function DeliveryZipModal({ open, onClose }:{open:boolean; onClose:()=>void}){
  const [zip,setZip]=React.useState(""); const [err,setErr]=React.useState("");
  React.useEffect(()=>{ if(!open){ setZip(""); setErr(""); }},[open]);
  const okZip=/^\d{5}$/.test(zip);
  function submit(e?:React.FormEvent){ e?.preventDefault(); if(!okZip){setErr("Enter a 5‑digit ZIP."); return;}
    if(!DELIVERY_ZIPS.includes(zip)){ setErr("Sorry, we don't deliver there yet."); return; }
    location.href=`/order?method=delivery&zip=${zip}`; }
  return <AnimatePresence>{open && (<>
    <motion.div aria-hidden className="fixed inset-0 z-[60] bg-black/50"
      initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={onClose}/>
    <motion.div role="dialog" aria-modal="true" className="fixed inset-0 z-[70] flex items-center justify-center p-4"
      initial={{opacity:0,scale:0.98}} animate={{opacity:1,scale:1}} exit={{opacity:0,scale:0.98}}>
      <div className="w-full max-w-md rounded-2xl bg-background border shadow-2xl">
        <div className="p-5 border-b"><h3 className="text-lg font-semibold">Check Local Delivery</h3>
          <p className="text-sm text-muted-foreground">Enter your ZIP to see if we deliver to you.</p></div>
        <form onSubmit={submit} className="p-5 space-y-4">
          <div><label htmlFor="zip" className="text-sm">ZIP Code</label>
            <input id="zip" inputMode="numeric" pattern="\d*" maxLength={5} value={zip}
              onChange={(e)=>setZip(e.target.value.replace(/[^0-9]/g, "").slice(0,5))}
              className="mt-1 w-full rounded-xl border px-3 py-2 outline-none focus:ring-4 focus:ring-primary/20" placeholder="e.g. 05819"/>
            {err && <p className="mt-2 text-sm text-red-600">{err}</p>}</div>
          <div className="flex items-center justify-end gap-2 pt-2">
            <Button type="button" variant="outline" className="rounded-xl" onClick={onClose}>Cancel</Button>
            <Button type="submit" className="rounded-xl">Continue</Button>
          </div>
        </form>
      </div>
    </motion.div></>)}</AnimatePresence>;
}

export default function SplitLanding(){
  const [active,setActive]=React.useState("left");
  const [zipOpen,setZipOpen]=React.useState(false);
  return <div className="min-h-screen w-full bg-background text-foreground">
    <header className="sticky top-0 z-50 w-full border-b bg-background/70 backdrop-blur">
      <div className="w-full px-4 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="size-9 rounded-xl bg-primary/10 flex items-center justify-center"><span className="text-primary font-black">TFV</span></div>
          <div><p className="text-sm font-semibold leading-tight">Texas Farms Vermont</p><p className="text-xs text-muted-foreground -mt-1">Pasture • Solar • Data</p></div>
        </div>
        <nav className="hidden md:flex items-center gap-6 text-sm">
          <a className="hover:text-primary" href="#story">Our Story</a>
          <a className="hover:text-primary" href="#shop">Shop</a>
          <a className="hover:text-primary" href="#wholesale">Wholesale</a>
          <a className="hover:text-primary" href="#contact">Contact</a>
          <Button size="sm" className="rounded-2xl">Preorder</Button>
        </nav>
        <MobileMenu/>
      </div>
    </header>
    <main className="w-full">
      <div className="flex flex-col md:flex-row min-h-[calc(100vh-64px)] w-full">
        {SECTIONS.map(s=>(<Panel key={s.id} section={s} active={active===s.id}
          onMouseEnter={()=>setActive(s.id)} onFocus={()=>setActive(s.id)} onClick={()=>setActive(s.id)}
          onRequestDelivery={()=>setZipOpen(true)}/>))}
      </div>
    </main>
    <DeliveryZipModal open={zipOpen} onClose={()=>setZipOpen(false)}/>
  </div>;
}

function MobileMenu(){
  const [open,setOpen]=React.useState(false);
  React.useEffect(()=>{function onKey(e:any){if(e.key==="Escape") setOpen(false);} window.addEventListener("keydown",onKey); return ()=>window.removeEventListener("keydown",onKey);},[]);
  React.useEffect(()=>{function onResize(){ if(window.matchMedia("(min-width: 768px)").matches) setOpen(false);} window.addEventListener("resize", onResize); return ()=>window.removeEventListener("resize", onResize);},[]);
  const Links = () => (<ul className="flex flex-col gap-4 py-4">
    <li><a className="block px-1 py-1" href="#story" onClick={()=>setOpen(false)}>Our Story</a></li>
    <li><a className="block px-1 py-1" href="#shop" onClick={()=>setOpen(false)}>Shop</a></li>
    <li><a className="block px-1 py-1" href="#wholesale" onClick={()=>setOpen(false)}>Wholesale</a></li>
    <li><a className="block px-1 py-1" href="#contact" onClick={()=>setOpen(false)}>Contact</a></li>
    <li><Button className="w-full rounded-2xl" onClick={()=>setOpen(false)}>Preorder</Button></li>
  </ul>);
  return <div className="md:hidden">
    <button className="inline-flex items-center p-2 rounded-lg border" aria-label={open? "Close menu":"Open menu"} aria-expanded={open} onClick={()=>setOpen(v=>!v)}><Menu className="w-5 h-5"/></button>
    <AnimatePresence>{open && (<>
      <motion.div key="backdrop" className="fixed inset-0 z-40 bg-black/40" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} onClick={()=>setOpen(false)}/>
      <motion.div key="sheet" className="fixed top-[56px] left-0 right-0 z-50 bg-background border-b shadow-lg" initial={{height:0}} animate={{height:"auto"}} exit={{height:0}} transition={{duration:0.25,ease:"easeOut"}}>
        <div className="px-4"><Links/></div>
      </motion.div></>)}</AnimatePresence>
  </div>;
}

function Panel({section,active,onMouseEnter,onFocus,onClick,onRequestDelivery}:any){
  return <motion.section layout onMouseEnter={onMouseEnter} onFocus={onFocus} onClick={onClick} role="button" tabIndex={0} aria-pressed={active}
    animate={{flexBasis: active? "60%":"40%"}} initial={false} transition={{duration:0.4,ease:"easeOut"}}
    className={["relative group flex items-end md:items-center justify-center overflow-hidden","w-full md:w-auto flex-1","min-h-[50vh] md:min-h-[calc(100vh-64px)]","outline-none focus:ring-4 focus:ring-primary/30"].join(" ")}
    style={{backgroundImage:`url(${section.bgImage})`, backgroundSize:"cover", backgroundPosition:"center"}}>
    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/35 transition-colors duration-300"/>
    <div className="absolute inset-0 bg-gradient-to-t md:bg-gradient-to-r from-black/60 via-black/30 to-transparent"/>
    <div className="relative z-10 w-full max-w-xl p-6 md:p-10 grid gap-6 md:gap-8 text-white">
      <header className="space-y-1"><h2 className="text-3xl md:text-5xl font-extrabold tracking-tight drop-shadow">{section.title}</h2>
      <p className="text-sm md:text-base text-white/80">{section.subtitle}</p></header>
      <div className="grid grid-cols-1 gap-4">{section.items.map((item:any)=>(
        <Card key={item.title} className="bg-white/90 backdrop-blur text-gray-900 border-0 shadow-lg rounded-2xl overflow-hidden">
          <CardHeader className="pb-2"><CardTitle className="flex items-center gap-2 text-lg">{item.icon}{item.title}</CardTitle></CardHeader>
          <CardContent className="flex items-center justify-between gap-3 pt-0">
            <p className="text-sm text-gray-600">{item.description}</p>
            {item.href==="#local-delivery" ? (
              <Button size="sm" className="rounded-xl" onClick={onRequestDelivery}>Check ZIP<ArrowRight className="ml-1 w-4 h-4"/></Button>
            ):(
              <Button asChild size="sm" className="rounded-xl"><a href={item.href}>Explore<ArrowRight className="ml-1 w-4 h-4"/></a></Button>
            )}
          </CardContent>
        </Card>))}
      </div>
    </div>
    <AnimatePresence>{active && (<motion.div key="activeGlow" initial={{opacity:0}} animate={{opacity:1}} exit={{opacity:0}} className="pointer-events-none absolute inset-0">
      <div className="absolute inset-0 border-2 border-white/20 rounded-none"/></motion.div>)}</AnimatePresence>
  </motion.section>;
}
