# GitHub Pages build of Split Landing

## How to use
1) Replace the base path in `vite.config.ts`:
```ts
base: "/your-repo-name/"
```
2) Commit and push to a repo on GitHub (default branch `main`).
3) On GitHub → **Settings → Pages** → Source = **GitHub Actions**.
4) Push to `main` to trigger the workflow. Your site will be available at:
```
https://<your-username>.github.io/<your-repo-name>/
```

### Local development
```bash
npm install
npm run dev
npm run build
npm run preview
```

We also include a `404.html` (copy of `index.html`) so GH Pages can serve your SPA routes.
