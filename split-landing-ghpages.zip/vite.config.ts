import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// IMPORTANT: replace `your-repo-name` below with the actual GitHub repo name
export default defineConfig({
  plugins: [react()],
  base: "/your-repo-name/", // <-- GH Pages base path (owner.github.io/repo)
});
