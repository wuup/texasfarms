/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{ts,tsx}"],
  theme: {
    extend: {
      colors: {
        background: { DEFAULT: "#0b0b0b" },
        foreground: { DEFAULT: "#f5f5f5" },
        primary: { DEFAULT: "#f97316" },
        "muted-foreground": "#9ca3af"
      }
    },
  },
  plugins: [],
}
